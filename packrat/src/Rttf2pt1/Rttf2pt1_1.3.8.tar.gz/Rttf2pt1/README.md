# Rttf2pt1

The Rttf2p1 package for R is meant to be used with the [extrafont](https://github.com/wch/extrafont) package.

This package contains the utility program `ttf2pt1`, and is in its own package for licensing reasons.
It will be compiled on installation, so you need a build environment on your system.

# Licensing notes

This product includes software developed by the TTF2PT1 Project and its contributors.
