### =========================================================================
### The type() getter and setter
### -------------------------------------------------------------------------
###


setGeneric("type", function(x) standardGeneric("type"))

setGeneric("type<-", function(x, value) standardGeneric("type<-"))

